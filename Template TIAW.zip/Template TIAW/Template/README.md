# Free Forum Template
A free HTML-CSS-JavaScript template of a community discussion website.

### [Watch Tutorial On Youtube.](https://youtu.be/knGk9aUr4Do)

### Screenshots

## Home Page

---

![](https://i.ibb.co/qWcy2zH/forums-home-page.png)

## Posts Page

---

![](https://i.ibb.co/ZLb6WvG/posts-page.png)

## Detail Page

---

![](https://i.ibb.co/wWrw8Dj/detail-page.png)


